from .linear_syst_methods import eliminacion_gaussiana, descomposicion_LU, resolver_LU, matriz_aumentada, separar_m_aumentada  # type: ignore
from .min_cuadrados import ajustar_min_cuadrados  # type: ignore
